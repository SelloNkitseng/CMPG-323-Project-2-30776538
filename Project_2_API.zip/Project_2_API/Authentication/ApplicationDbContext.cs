﻿namespace Project_2_API.Authentication
{
    public class ApplicationDbContext
    {
    }
}
