﻿namespace Project_2_API.Controllers
{
    public class AuthenticateController
    {
    }
}
